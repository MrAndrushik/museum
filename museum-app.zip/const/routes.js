export const MAIN_ROUTE = "/";
export const MUSEUM_ON_DEPARTURE = "/muzei-na-viezd";
export const CORPORATE_OF_THE_USSR = "/meropriatia-ussr";
export const HOLIDAY_AT_THE_MUSEUM = "/prazdnik-v-muzee";
export const MUSEUM = "/o-nas";
export const NEWS = "/news";
export const CONTACT = "contact";
